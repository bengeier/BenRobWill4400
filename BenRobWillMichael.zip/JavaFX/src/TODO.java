/**
 * Created by wepperson on 7/24/17.
 */
public class TODO {

// HIGH PRIORITY

	//TODO adding a new attraction should be sent to manager for approval
    
	//TODO managers should be able to delete any review they want from a city 
		//(mySQL DELETE and delete button to appear if isManager)
	//TODO managers should be able to delete any review they want from an attraction

	//QUESTION: do we want user to be taken to a city/attraction screen after adding that city/attraction, even if it is still pending?

// LOW PRIORITY

}
